package com.cg.demo.labD;

public interface EmployeeService {
public Employee getDetails(int empId);
}
